#include "stm32g4xx.h"
#include "usbd_core.h"
#include "usbd_cdc.h"
#include "stm32g4xx_hal.h"
#include "usbd_cdc_if.h"
#include "main.h"
#include "arm_math.h"

USBD_HandleTypeDef hUsbDeviceFS;
extern USBD_DescriptorsTypeDef CDC_Desc;
extern PCD_HandleTypeDef hpcd_USB_FS;
volatile uint32_t tick_counter,error,_1ms_tick,I2C_tx_byte_counter,I2C_rx_byte_counter,pO2_sample_counter,max_diff;
volatile utopc_data To_PC;
volatile sreg_data Reg_Data={50,50,50,50,LED1_LED2_ENABLED,MODE_2_LED_PW_2};
volatile uint16_t pulse,SpO2;
volatile uint8_t TX_Byte,RX_Byte,write_bytes[4];
volatile ufifo_data FIFO_data;
uint32_t IR_max_index_1,IR_max_index_2,IR_min_index;
q31_t IR_Samples[PO2_SAMPLE_SIZE],RED_Samples[PO2_SAMPLE_SIZE],IR_max,IR_min;
float Ratio;
const float a_coeff=-16.666666,b_coeff=8.333333,c_coeff=100.0;


void SysTick_Handler(void){
  _1ms_tick++;
	if(tick_counter>48){//23=25ms, 98=100ms
		tick_counter=0;
		GLOBAL_FLAGS->CONFIGURE=SET;
    GLOBAL_FLAGS->PROCESS_MESSAGE=SET;		
	  }
	  else{
		tick_counter++;
	}	
}

void EXTI15_10_IRQHandler(void){
	EXTI->PR1 |= EXTI_PR1_PIF10;
	//GPIOA->ODR^=GPIO_ODR_OD0;
	I2C_tx_byte_counter=0;
	I2C_rx_byte_counter=14;
	I2C2->ISR |= I2C_ISR_TXE;//flush the buffer	
	I2C2->CR2=0x000120AF;	//next FIFO read
}

void USB_LP_IRQHandler(void)
{
  HAL_PCD_IRQHandler(&hpcd_USB_FS);
}

void I2C2_EV_IRQHandler(void){//SCL PA9 & SDA PA8
	//GPIOA->BSRR=GPIO_BSRR_BS0;	
	uint32_t I2C_ISR_Read;
	I2C_ISR_Read=I2C2->ISR;
	if(I2C_ISR_Read & I2C_ISR_TC){
		if(GLOBAL_FLAGS->READ_FIFO_MODE){
		I2C2->CR2=0x020C24AF;//start read 12 bytes
		}
		else{
		I2C2->CR2=0x020124AF;	//start read one byte future)
		}
	}
	if(I2C_ISR_Read & I2C_ISR_TXE){
	I2C2->TXDR=write_bytes[I2C_tx_byte_counter++];
	}
	if(I2C_ISR_Read & I2C_ISR_RXNE){
		if(GLOBAL_FLAGS->READ_FIFO_MODE){
			if((I2C_rx_byte_counter==3)||(I2C_rx_byte_counter==7)||(I2C_rx_byte_counter==11)){
				I2C_rx_byte_counter--;
			}
		if(I2C_rx_byte_counter==0){
			GLOBAL_FLAGS->UPDATE=SET;
		}
		FIFO_data._bytes[I2C_rx_byte_counter--]=I2C2->RXDR;	
		}
		else{
		RX_Byte=I2C2->RXDR;		
		}
	}	
	//GPIOA->BRR=GPIO_BRR_BR0;
}	

void SystemClock_Config(void){
	RCC->PLLCFGR = 0x01504813;//144MHz PLL sysclk 48MHz USB clk from 8MHz crystal
	RCC->CCIPR=RCC_CCIPR_CLK48SEL_1;//PLL Q clock source
	RCC->APB1ENR1 |= RCC_APB1ENR1_PWREN | RCC_APB1ENR1_USBEN | RCC_APB1ENR1_I2C2EN;//gate PWR, USB clk & I2C
	RCC->CR |= RCC_CR_HSEON | RCC_CR_PLLON;
	PWR->CR5 &= ~PWR_CR5_R1MODE;//enable boost mode
	FLASH->ACR = FLASH_ACR_DBG_SWEN | FLASH_ACR_PRFTEN | FLASH_ACR_ICEN | FLASH_ACR_DCEN | FLASH_ACR_LATENCY_4WS;
	RCC->CFGR |= RCC_CFGR_SW_PLL;//run from PLL
	RCC->CR &= ~RCC_CR_HSION;//turn off HSI
}

void Error_Handler(void)
{
	error=10;
}

void HAL_Delay(__IO uint32_t Delay)
{
  while (Delay)
  {
    if (SysTick->CTRL & SysTick_CTRL_COUNTFLAG_Msk)
    {
      Delay--;
    }
  }
}

void InitI2C2(void){//
	I2C2->CR1 &= ~I2C_CR1_PE;//disable I2C
	I2C2->TIMINGR=0xE057FD;//0x30112622;//400kHz cube MX 0xE057FD 
	NVIC_SetPriority(I2C2_EV_IRQn, 8);
	NVIC_EnableIRQ(I2C2_EV_IRQn);
}	

int main(void){
	uint32_t RED_sample,IR_sample,Green_sample,Blue_sample;
	SystemClock_Config();
	RCC->AHB2ENR |= RCC_AHB2ENR_GPIOAEN | RCC_AHB2ENR_GPIOBEN;
	GPIOA->OTYPER = GPIO_OTYPER_OT_8 | GPIO_OTYPER_OT_9;//scl open drain
	GPIOA->AFR[1]=0x44;
	GPIOA->MODER =0xABCAFFFD;
	EXTI->FTSR1 |= EXTI_FTSR1_FT10;//falling edge
	EXTI->IMR1  |= EXTI_IMR1_IM10; //Mask 
	NVIC_SetPriority(EXTI15_10_IRQn,2);//sample ready interrupt  
	
	InitI2C2();
	GPIOB->MODER=0xFFFDFEBF;
	tick_counter=0;
	SysTick_Config(144e3);//144e3 =1ms at 144MHz mulptiple of 48mHz needed by USB
	
	  /* Init Device Library, add supported class and start the library. */
  if (USBD_Init(&hUsbDeviceFS, &CDC_Desc, DEVICE_FS) != USBD_OK) {
    error=1;
  }	
  if (USBD_RegisterClass(&hUsbDeviceFS, &USBD_CDC) != USBD_OK) {
    error=2;
  }
  if (USBD_CDC_RegisterInterface(&hUsbDeviceFS, &USBD_Interface_fops_FS) != USBD_OK) {
    error=3;
  }
  if (USBD_Start(&hUsbDeviceFS) != USBD_OK) {
   error=4;
  } 
  configure_MAX86916();
	while(1){
		   if(GLOBAL_FLAGS->UPDATE_REG_DATA){
       GLOBAL_FLAGS->UPDATE_REG_DATA=GLOBAL_FLAGS->READ_FIFO_MODE=RESET;				
       NVIC_DisableIRQ(EXTI15_10_IRQn);
				 configure_MAX86916();
			}
			else{
			if(GLOBAL_FLAGS->UPDATE){			
			GLOBAL_FLAGS->UPDATE=RESET;	 		
			RED_sample=(FIFO_data.sled.RED&0x7FFFF);
			IR_sample=(FIFO_data.sled.IR&0x7FFFF);
			Green_sample=(FIFO_data.sled.GREEN&0x7FFFF);
			Blue_sample=(FIFO_data.sled.BLUE&0x7FFFF);	
			RED_Samples[pO2_sample_counter]=RED_sample;		
      IR_Samples[pO2_sample_counter++]=IR_sample;				
			if(pO2_sample_counter>PO2_SAMPLE_SIZE){//
				pO2_sample_counter=0;
				arm_max_q31(IR_Samples,PO2_SAMPLE_SIZE,&IR_max,&IR_max_index_1);
				IR_min_index=IR_max_index_1;
				if(IR_min_index<PO2_SAMPLE_SIZE/2){	//leave enough room for the next peak			
					while(IR_Samples[IR_min_index]>IR_Samples[IR_min_index+1]){
					IR_min_index++;
					}	
					IR_max_index_2=IR_min_index;
								while(IR_Samples[IR_max_index_2]<IR_Samples[IR_max_index_2+1]){//find next peak after max
					      IR_max_index_2++;
					}
				max_diff=IR_max_index_2-IR_max_index_1;
				}
				else{
					while(IR_Samples[IR_min_index]>IR_Samples[IR_min_index-1]){
					IR_min_index--;
					}
					IR_max_index_2=IR_min_index;
					while(IR_Samples[IR_max_index_2]<IR_Samples[IR_max_index_2-1]){//find next peak after max
					IR_max_index_2--;
				}
				max_diff=IR_max_index_1-IR_max_index_2;				
				}
				if(max_diff>30){
        pulse=(uint16_t)(3000.0f/(float)max_diff+0.5);
				}					
				Ratio=((((float)RED_Samples[IR_max_index_1]-(float)RED_Samples[IR_min_index])/(float)RED_Samples[IR_max_index_1])/
					     (((float)IR_max-(float)IR_Samples[IR_min_index])/(float)IR_max));  		
				SpO2=(uint16_t)((Ratio*Ratio*a_coeff)+(Ratio*b_coeff)+c_coeff+0.05f);		
			}}}			
			if(GLOBAL_FLAGS->PROCESS_MESSAGE){
      GLOBAL_FLAGS->PROCESS_MESSAGE=RESET;			
 	    To_PC.sdata.RED=RED_sample;
			To_PC.sdata.IR=IR_sample;
			To_PC.sdata.GREEN=Green_sample;
      To_PC.sdata.BLUE=Blue_sample;				
			To_PC.sdata.Pulse=pulse;
			To_PC.sdata.SpO2=SpO2;
	    CDC_Transmit_FS((uint8_t*)To_PC._bytes, sizeof To_PC._bytes);		
			}}
				if(error){
				//GPIOA->ODR^=GPIO_ODR_OD0;	
}}

void configure_MAX86916(void){
	uint32_t Configuration_sequence=DEVICE_RESET;
	while(Configuration_sequence){
			if(GLOBAL_FLAGS->CONFIGURE){//provides timimg between I2C messages
			GLOBAL_FLAGS->CONFIGURE=RESET;
			switch(Configuration_sequence){
				case EXIT_START_UP:
				break;
				case DEVICE_RESET:
			  Configuration_sequence++;
				write_bytes[REG_ADDR]=MODE_CONFIG_1_REG;
			  write_bytes[REG_DATA]=MODE_1_RESET;
				I2C_tx_byte_counter=0;
				I2C2->ISR |= I2C_ISR_TXE;//flush the buffer
				I2C2->CR1 = I2C_WRITE_MODE;//
				I2C2->CR2=0x020220AF;//Start tx 2 bytes address 0x57 autoend					
				break;
				case INTERRUPT_EN_1:
			  Configuration_sequence++;
				write_bytes[REG_ADDR]=INT_EN_1_REG;
			  write_bytes[REG_DATA]=SMP_RDY_ON;
				I2C_tx_byte_counter=0;
				I2C2->ISR |= I2C_ISR_TXE;//flush the buffer
				I2C2->CR1 = I2C_WRITE_MODE;//
				I2C2->CR2=0x020220AF;//Start tx 2 bytes address 0x57 autoend
			  break;					
				case CONFIG_FIFO:
			  Configuration_sequence++;
				write_bytes[REG_ADDR]=FIFO_CONFIG_REG;
			  write_bytes[REG_DATA]=FIFO_CONFIG_SMP_AVE_1;//0x0;//0xA0=32 sample avg 
				I2C_tx_byte_counter=0;
				I2C2->ISR |= I2C_ISR_TXE;//flush the buffer
				I2C2->CR2=0x020220AF;//Start tx 2 bytes address 0x57 autoend	
        break;
				case IR_CURRENT:
			  Configuration_sequence++;
				write_bytes[REG_ADDR]=LED1_PA_REG;
			  write_bytes[REG_DATA]=Reg_Data.IR_mA;
				I2C_tx_byte_counter=0;
				I2C2->ISR |= I2C_ISR_TXE;//flush the buffer
				I2C2->CR2=0x020220AF;//Start tx 2 bytes address 0x57 autoend	
        break;	
				case RED_CURRENT:
			  Configuration_sequence++;
				write_bytes[REG_ADDR]=LED2_PA_REG;
			  write_bytes[REG_DATA]=Reg_Data.Red_mA;
				I2C_tx_byte_counter=0;
				I2C2->ISR |= I2C_ISR_TXE;//flush the buffer
				I2C2->CR2=0x020220AF;//Start tx 2 bytes address 0x57	
        break;
				case GREEN_CURRENT:
			  Configuration_sequence++;
				write_bytes[REG_ADDR]=LED3_PA_REG;
			  write_bytes[REG_DATA]=Reg_Data.Green_mA;
				I2C_tx_byte_counter=0;
				I2C2->ISR |= I2C_ISR_TXE;//flush the buffer
				I2C2->CR2=0x020220AF;//Start tx 2 bytes address 0x57	
        break;
				case BLUE_CURRENT:
			  Configuration_sequence++;
				write_bytes[REG_ADDR]=LED4_PA_REG;
			  write_bytes[REG_DATA]=Reg_Data.Blue_mA;
				I2C_tx_byte_counter=0;
				I2C2->ISR |= I2C_ISR_TXE;//flush the buffer
				I2C2->CR2=0x020220AF;//Start tx 2 bytes address 0x57	
        break;
				case LED_SEQ_1:
			  Configuration_sequence++;
				write_bytes[REG_ADDR]=LED_SEQ_1_REG;
			  write_bytes[REG_DATA]=0x34;
				I2C_tx_byte_counter=0;
				I2C2->ISR |= I2C_ISR_TXE;//flush the buffer
				I2C2->CR2=0x020220AF;//Start tx 2 bytes address 0x57	
        break;	
				case LED_SEQ_2:
			  Configuration_sequence++;
				write_bytes[REG_ADDR]=LED_SEQ_2_REG;
			  write_bytes[REG_DATA]=0x21;
				I2C_tx_byte_counter=0;
				I2C2->ISR |= I2C_ISR_TXE;//flush the buffer
				I2C2->CR2=0x020220AF;//Start tx 2 bytes address 0x57	
        break;
				case DEVICE_MODE_1:
			  Configuration_sequence++;
				write_bytes[REG_ADDR]=MODE_CONFIG_1_REG;
			  write_bytes[REG_DATA]=Reg_Data.Mode;
				I2C_tx_byte_counter=0;
				I2C2->ISR |= I2C_ISR_TXE;//flush the buffer
				I2C2->CR2=0x020220AF;//Start tx 2 bytes address 0x57 autoend
			  break;
				case DEVICE_MODE_2:
				Configuration_sequence++;
				write_bytes[REG_ADDR]=MODE_CONFIG_2_REG;
			  write_bytes[REG_DATA]=MODE_2_SR_1 + Reg_Data.LED_pulse_width; 
				I2C_tx_byte_counter=0;
				I2C2->ISR |= I2C_ISR_TXE;//flush the buffer
				I2C2->CR2=0x020220AF;//Start tx 2 bytes address 0x57 autoend
			  break;				
				case READ_STATUS:
				Configuration_sequence++;
				write_bytes[REG_ADDR]=STATUS_REG;
				I2C2->CR1 = I2C_READ_MODE;
		    I2C_tx_byte_counter=0;
			  I2C_rx_byte_counter=1;
			  I2C2->ISR |= I2C_ISR_TXE;//flush the buffer	
			  I2C2->CR2=0x000120AF;	//get things rolling by reading the status reg which enables the sample interrupt
				break;				
				case INIT_RUN_MODE:
				Configuration_sequence=EXIT_START_UP;
				I2C_tx_byte_counter=0;
				GLOBAL_FLAGS->READ_FIFO_MODE=SET;				
				write_bytes[REG_ADDR]=FIFO_DATA_REG;
				EXTI->PR1 |= EXTI_PR1_PIF10;
				NVIC_EnableIRQ(EXTI15_10_IRQn);
				break;
}}}}

