#ifndef __MAIN_H
#define __MAIN_H

#include <stdint.h>

#define I2C_WRITE_MODE I2C_CR1_PE | I2C_CR1_TXIE
#define I2C_READ_MODE I2C_CR1_PE | I2C_CR1_RXIE | I2C_CR1_TCIE | I2C_CR1_TXIE

#define REG_ADDR          0
#define REG_DATA          1
#define STATUS_REG        0
#define INT_EN_1_REG      2
#define FIFO_DATA_REG     7
#define FIFO_CONFIG_REG   8
#define MODE_CONFIG_1_REG 9
#define MODE_CONFIG_2_REG 10
#define LED1_PA_REG       12
#define LED2_PA_REG       13
#define LED3_PA_REG       14
#define LED4_PA_REG       15
#define LED_SEQ_1_REG     19
#define LED_SEQ_2_REG     20
#define FIFO_CONFIG_SMP_AVE_0   0x0
#define FIFO_CONFIG_SMP_AVE_1   0x20
#define FIFO_CONFIG_SMP_AVE_2   0x40
#define FIFO_CONFIG_SMP_AVE_5   0xA0//32
#define MODE_DISABLED 0

#define LED1_ENABLED  1
#define LED1_LED2_ENABLED 2
#define PO2_SAMPLE_SIZE 100
#define MODE_1_SHUTDOWN 0x80
#define MODE_1_RESET    0x40
#define MODE_2_LED_PW_0 0
#define MODE_2_LED_PW_1 1
#define MODE_2_LED_PW_2 2
#define MODE_2_LED_PW_3 3 
#define MODE_2_SR_0 0
#define MODE_2_SR_1 4
#define MODE_2_SR_2 8
#define MODE_2_SR_5 0x14//1000 samples/sec 
#define MODE_2_SR_6 0x18//1600 samples/sec 
#define MODE_2_SR_7 0x1C
#define SMP_RDY_ON  0x40

typedef struct{
volatile uint32_t UPDATE;
volatile uint32_t PROCESS_MESSAGE;
volatile uint32_t CONFIGURE;
volatile uint32_t UPDATE_REG_DATA;	
volatile uint32_t WRITE_REG_DATA;
volatile uint32_t READ_FIFO_MODE;	
}flags_type;

#define GLOBAL_FLAGS ((flags_type*)0x2207FF80)//SRAM1 last word 6 cycles
#define GLOBAL_FLAGS_BASE 0x20003FFC


typedef union{
	uint8_t _bytes[4];
	uint32_t _int;
}ubytes2int;

typedef union{
	uint8_t _bytes[16];
	struct{
	uint32_t RED;
	uint32_t IR;
	uint32_t GREEN;	
	uint32_t BLUE;	
	}sled;
}ufifo_data;

typedef union{
	uint8_t _bytes[20];
	struct{
	uint32_t RED;
	uint32_t IR;
	uint32_t GREEN;
	uint32_t BLUE;	
	uint16_t Pulse;
 	uint16_t SpO2;		
	}sdata;
}utopc_data;

typedef struct{
	uint8_t IR_mA;
	uint8_t Red_mA;
	uint8_t Green_mA;
	uint8_t Blue_mA;
  uint8_t Mode;
	uint8_t LED_pulse_width;
}sreg_data;

typedef enum{
	EXIT_START_UP,
	DEVICE_RESET,
	INTERRUPT_EN_1,
	CONFIG_FIFO,
	IR_CURRENT,
	RED_CURRENT,
  GREEN_CURRENT,
  BLUE_CURRENT,	
	LED_SEQ_1,
	LED_SEQ_2,
	DEVICE_MODE_1,
	DEVICE_MODE_2,
	READ_STATUS,
	INIT_RUN_MODE
}estartup;

typedef enum{
  IR_MA=85,
  RED_MA,
	GREEN_MA,
	BLUE_MA,
  OP_MODE,
	LED_PW
}ecommands;

void Error_Handler(void);
void configure_MAX86916(void);
#endif
